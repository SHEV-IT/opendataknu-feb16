setwd("�:\\R_material_kpi") ## path to files 
source(".\\format.R")
source(".\\getData.R")
source(".\\plotData.R")
source(".\\analyse.R")

kpi_get <- getData(spring = "kpi",type = "get")
kpi_send <- getData(spring = "kpi",type = "send")

getUniqueNumTable(kpi_get)
getUniqueNumTable(kpi_send)

kpi_get <- formatGeneral(kpi_get)
kpi_send <- formatGeneral(kpi_send)

getUniqueNumTable(kpi_get)
getUniqueNumTable(kpi_send)

sort(unique(kpi_get$name_rec))
sort(unique(kpi_send$name_sender))

u_kpi_get_name_rec <- sort(unique(kpi_get$name_rec))
u_kpi_get_name_rec <- gsub("(����|��|���|������)(?![ ])"," \\1 ", u_kpi_get_name_rec, perl = TRUE)

u_words_name_rec <- table(unlist(strsplit(unique(u_kpi_get_name_rec),split=" ")))
u_words_name_rec_sub <- u_words_name_rec[u_words_name_rec>1]
sort(u_words_name_rec_sub)
u_words_name_rec_sub_names <- names(u_words_name_rec_sub[order(nchar(names(u_words_name_rec_sub)),decreasing = TRUE)])
u_words_name_rec_sub_names
junk <- lapply(u_words_name_rec_sub_names,function(s){ u_kpi_get_name_rec <<- gsub(paste0("\\b",s,"\\b",collapse = ""),"",u_kpi_get_name_rec)})
u_kpi_get_name_rec
u_kpi_get_name_rec <- gsub("[()]","",u_kpi_get_name_rec)
u_kpi_get_name_rec <- gsub("^[ ]+|[ ]+$","",u_kpi_get_name_rec)
u_kpi_get_name_rec <- gsub("[ ]+"," ",u_kpi_get_name_rec)
sort(unique(u_kpi_get_name_rec))

kpi_get[grep("�����",kpi_get$name_rec),]
kpi_send[kpi_send$code_rec=="39421842",]
apply(kpi_send[kpi_send$code_rec=="39421842",3:10],2,unique)
min(kpi_send[kpi_send$code_rec=="39421842",]$date)
kpi_send[2588,]

kpi_get_inner_code <- getInternal(kpi_get)
kpi_send_inner_code <- getInternal(kpi_send)
kpi_get_inner_code <- kpi_get_inner_code[order(kpi_get_inner_code$transaction),]
kpi_send_inner_code <- kpi_send_inner_code[order(kpi_send_inner_code$transaction),]
all(kpi_get_inner_code == kpi_send_inner_code)
all(kpi_get_inner_code == kpi_send_inner_code, na.rm = TRUE)

kpi_get_complete <- kpi_get[complete.cases(kpi_get),]
kpi_get_incomplete <- kpi_get[!complete.cases(kpi_get),]
kpi_send_complete <- kpi_send[complete.cases(kpi_send),] 
kpi_send_incomplete <- kpi_send[!complete.cases(kpi_send),]

kpi_get_invalid <- validateCode(kpi_get_complete)
kpi_send_invalid <- validateCode(kpi_send_complete)

kpi_send[kpi_send$code_rec=="xxxxxxxxxx",]
sum(kpi_send[kpi_send$code_rec=="xxxxxxxxxx",]$sum)
sort(table(kpi_send[kpi_send$code_rec=="xxxxxxxxxx",]$name_rec))
sum(kpi_send[kpi_send$code_rec=="xxxxxxxxxx"&kpi_send$name_rec=="��� �������� � � ",]$sum)

kpi_send[kpi_send$code_rec=="568362439",]
kpi_send[kpi_send$code_rec=="200009888",]
dim(kpi_send[!is.na(kpi_send$bank_rec) & kpi_send$bank_rec=="Test Bank",])
sum(kpi_send[!is.na(kpi_send$bank_rec) & kpi_send$bank_rec=="Test Bank",]$sum)

kpi_get_outer_code <- getExternal(kpi_get_complete)
kpi_send_outer_code <- getExternal(kpi_send_complete)

kpi_send_rec_table <- getTableSumOnName(kpi_send_outer_code,type="rec")

plotSumOnName(kpi_send_rec_table)
plotAverageOnName(kpi_send_rec_table)
plotTimesOnName(kpi_send_rec_table)

dim(kpi_send_rec_table)[1]

kpi_send_rec_table_sub <- kpi_send_rec_table[!grepl("��|��i|����|����$",row.names(kpi_send_rec_table)),]

plotSumOnName(kpi_send_rec_table_sub)
plotAverageOnName(kpi_send_rec_table_sub)
plotTimesOnName(kpi_send_rec_table_sub)

kpi_send_rec_table_sub <- kpi_send_rec_table_sub[!grepl("���|���",row.names(kpi_send_rec_table_sub)),]

dim(kpi_send_rec_table_sub)[1]
plotSumOnName(kpi_send_rec_table_sub)
plotAverageOnName(kpi_send_rec_table_sub)
plotTimesOnName(kpi_send_rec_table_sub)

ruol <- kpi_send[!is.na(kpi_send$name_rec)&grepl("����",kpi_send$name_rec),]
sum(ruol$sum)
apply(ruol[,3:10],2,unique)
summary(ruol$sum)
